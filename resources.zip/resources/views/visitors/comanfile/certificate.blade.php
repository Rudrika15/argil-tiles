<div class="certificate">
    <div class="bg-image">
        <div class="sec-title text-center">
            <h2>Why Choose Argil Group?</h2>
        </div>
        {{-- <img src="asset/images/argileimage/backgroundimage.jpg" alt="" width="100%"> --}}
    </div>
    <div class="container certificateicon">
        <div class="row">
            <div class="certificate-class">
                <div class="col-md-2">
                    <img src="asset/images/argileimage/certificate1.png" alt="" class="img-responsive">
                    <h3>ISO CERTIFIED</h3>
                </div>
                <div class="col-md-2">
                    <img src="asset/images/argileimage/certificate2.png" alt="" class="img-responsive">
                    <h3>TISI THAILAND STANDARD</h3>
                </div>
                <div class="col-md-2">
                    <img src="asset/images/argileimage/certificate3.png" alt="" class="img-responsive">
                    <h3>SLSI SRILANKAN STANDARD</h3>
                </div>
                <div class="col-md-2">
                    <img src="asset/images/argileimage/certificate4.png" alt="" class="img-responsive">
                    <h3>HIGHEST EXPORT AWARDS</h3>
                </div>
                <div class="col-md-2">
                    <img src="asset/images/argileimage/certificate5.png" alt="" class="img-responsive">
                    <h3>HIGHEST NATIONAL AWARDS</h3>
                </div>
            </div>
        </div>
    </div>
</div>
