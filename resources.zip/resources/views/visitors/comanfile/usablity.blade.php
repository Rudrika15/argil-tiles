

<div class="certificate1">
    <div class="bg-image">
        <div class="sec-title text-center">
            <h2>Enhancing the usability</h2>
        </div>
        {{-- <img src="asset/images/argileimage/backgroundimage.jpg" alt="" width="100%"> --}}
    </div>
    <div class="container certificateicon">
        <div class="row">
            <div class="certificate-class">
                <div class="col-md-2">
                    <img src="asset/images/argileimage/usablityimage1.png" alt="" class="img-responsive">
                    <h3>More Durable</h3>
                </div>
                <div class="col-md-2">
                    <img src="asset/images/argileimage/usablityimage2.png" alt="" class="img-responsive">
                    <h3>More Uniform</h3>
                </div>
                <div class="col-md-2">
                    <img src="asset/images/argileimage/usablityimage3.png" alt="" class="img-responsive">
                    <h3>Bacteria-Free</h3>
                </div>
                <div class="col-md-2">
                    <img src="asset/images/argileimage/usablityimage4.png" alt="" class="img-responsive">
                    <h3>Friendiler to the Environment</h3>
                </div>
                <div class="col-md-2">
                    <img src="asset/images/argileimage/usablityimage5.png" alt="" class="img-responsive">
                    <h3>Requires less Maintenance</h3>
                </div>
                <div class="col-md-2">
                    <img src="asset/images/argileimage/usablityimage5.png" alt="" class="img-responsive">
                    <h3>Longer Warranty</h3>
                </div>
            </div>
        </div>
    </div>
</div>
