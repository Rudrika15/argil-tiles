<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NewArrivals extends Model
{
    //
}
