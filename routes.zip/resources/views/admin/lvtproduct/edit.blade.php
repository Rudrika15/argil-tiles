@extends('admin.layouts.app')

@section('pageTitle','Dashboard')

@section('content')

{{-- <div class="row">
	<div class="col-md-12">

		@if ($message = Session::get('success'))

		<div class="alert alert-success alert-dismissible fade show" role="alert">
			<p>{{$message}}</p>
			<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
			</button>
		</div>

		@endif

	</div>
</div> --}}

<div class="main-content">
	<div class="row">
		<div class="col-md-12">
			<div class="float-left">
				<h2>SPC Product Edit</h2>
			</div>
			<div class="float-right">
				<a href="{{route('lvtshow')}}" class="btn btn-success">Back</a>
			</div>
		</div>
	</div>

	<form class="form-group" enctype="multipart/form-data" action="{{route('lvt.editcode')}}" method="post">
		@csrf
		<input type="hidden" name="id" value="{{$data->id}}">
		<div class="row">
			<div class="col-md-6">
				<div class="form-label-group">
					<input id="form_firstname" type="text" name="names" value="{{$data->names}}" class="form-control" placeholder="Names">
					<label for="form_firstname">Names</label>
				</div>
                <div class="form-label-group">
                    <select name="thicknesses" id="thicknesses" class="form-control" required>
                        <option value="" disabled selected>Thicknesses</option>
                        <option value="4MM,5MM,6MM"{{$data->thicknesses =='4MM,5MM,6MM'?'selected':''}}>4MM,5MM,6MM</option>

                    </select>
                </div>


				<div class="form-label-group">
					<input id="form_firstname" type="text" name="primarycolors" value="{{$data->primarycolors}}" class="form-control" placeholder="Primarycolors" required>
					<label for="form_firstname">Primarycolors</label>
				</div>

				<div class="form-label-group">
					<input id="form_firstname" type="text" name="edges" value="{{$data->edges}}" class="form-control" placeholder="Edges" required>
					<label for="form_firstname">Edges</label>
				</div>

				<div class="form-label-group">
					<input id="form_firstname" type="text" name="clicktype" value="{{$data->clicktype}}" class="form-control" placeholder="Clicktype" required>
					<label for="form_firstname">Clicktype</label>
				</div>


				<div class="form-label-group">
					<input id="form_firstname" type="text" name="shadeVariation" value="{{$data->shadeVariation}}" class="form-control" placeholder="Shadevariation" required>
					<label for="form_firstname">Shadevariation</label>
				</div>

				<div class="form-label-group">
					<input id="form_firstname" type="text" name="backingType" value="{{$data->backingType}}" class="form-control" placeholder="backingtype" required>
					<label for="form_firstname">Backingtype</label>
				</div>


				<div class="form-label-group">
					<input id="form_firstname" type="text" name="style" value="{{$data->style}}" class="form-control" placeholder="Style" required>
					<label for="form_firstname">Style</label>
				</div>


				<div class="form-label-group">
					<input id="form_firstname" type="text" name="wearLayer" value="{{$data->wearLayer}}" class="form-control" placeholder="Wearlayer" required>
					<label for="form_firstname">Wearlayer</label>
				</div>


                <div class="form-label-group">
                    <select name="bookmatch" id="bookmatch" class="form-control" required>
                        <option value="" disabled selected>Size</option>
                        @foreach($lvtsize as $lvtsize)
						<option value="{{$lvtsize->size}}"{{ $lvtsize->size == $data->bookmatch?'selected':'' }}>{{$lvtsize->size}}</option>
						@endforeach

                    </select>
                </div>
			</div>

			<div class="col-md-6">
				<div class="form-label-group">
					<input id="form_firstname" accept='image/*' onchange="readURL(this,'#img1')" type="file" name="mainImg" class="form-control" placeholder="Main Img">


					<label for="form_firstname">Main Img</label>
				</div>


				<div class="form-label-group">
					<input id="form_firstname" type="file" name="subImg1" accept='image/*' onchange="readURL(this,'#img2')" class="form-control" placeholder="subImg1">


					<label for="form_firstname">SubImg1</label>
				</div>

				<div class="form-label-group">
					<input id="form_firstname" type="file" name="subImg2" accept='image/*' onchange="readURL(this,'#img3')" class="form-control" placeholder="subImg2">
					<label for="form_firstname">SubImg2</label>
				</div>

				<div class="form-label-group">
					<input accept='image/*' onchange="readURL(this,'#img4')" id="form_firstname" type="file" name="subImg3" class="form-control" placeholder="subImg3">

					<label for="form_firstname">SubImg3</label>
				</div>

				<div class="form-label-group">
					<input accept='image/*' onchange="readURL(this,'#img5')" id="form_firstname" type="file" name="subImg4" class="form-control" placeholder="subImg4">
					<label for="form_firstname">SubImg4</label>
				</div>

				<div class="form-label-group">
					<input accept='image/*' onchange="readURL(this,'#img6')" id="form_firstname" type="file" name="subImg5" class="form-control" placeholder="subImg5">

					<label for="form_firstname">SubImg5</label>
				</div>


				<img src="{{url('spc')}}/{{$data -> mainImg}}" alt="Main Image" id="img1" style='height:150px;width:100px' class="mt-2">
				<img src="{{url('spc')}}/{{$data -> subImg1}}" alt="Sub-Img1" id="img2" style='height:150px;width:100px' class="mt-2">
				<img src="{{url('spc')}}/{{$data -> subImg2}}" alt="Sub-Img2" id="img3" style='height:150px;width:100px' class="mt-2">
				<img src="{{url('spc')}}/{{$data -> subImg3}}" alt="Sub-Img3" id="img4" style='height:150px;width:100px' class="mt-2">
				<img src="{{url('spc')}}/{{$data -> subImg4}}" alt="Sub-Img4" id="img5" style='height:150px;width:100px'  class="mt-2">
				<img src="{{url('spc')}}/{{$data -> subImg5}}" alt="Sub-Img5" id="img6" style='height:150px;width:100px'  class="mt-2">

			</div>
		</div>

		{{-- add meta propertys --}}
        <hr class="sidebar-divider my-4">

        <div class="row mb-4">
            <h4 class="m-3">Edit Meta Propertys for Spc Product</h4>
        </div>

        {{-- og titles --}}
        <div class="row mb-3">
            <div class="col-sm-12 col-lg-3 col-md-12">
                Og Title
            </div>
            <div class="col">
                <div class="form-label-group">
                    <input type="text" class="form-control" id="ogTitleEng" placeholder="English Title"
                        name="ogTitleEng" value="{{ $data1->ogTitleEng ?? ''}}">
                    <label for="">og title</label>
                </div>
            </div>

        </div>

        {{-- og Description --}}
        <div class="row mb-3">
            <div class="col-sm-12 col-lg-3 col-md-12">
                Og Description
            </div>
            <div class="col">
                <div class="form-label-group">
                    <input type="text" class="form-control" id="ogDescriptionEng" placeholder="English Description"
                        name="ogDescriptionEng" value="{{ $data1->ogDescriptionEng ?? ''}}">
                    <label for="">og description</label>
                </div>
            </div>

        </div>

        {{-- og image --}}
        <div class="row mb-3">
            <div class="col-sm-12 col-lg-3 col-md-12">
                Og Image
            </div>
            @if(!empty($data1) && !empty($data1->ogImage))
            <div class="col-2" id="imagepreview">
                <img id="ogImagePreview" src="{{ asset('ogimage/'.$data1->ogImage) }}" alt="Og Image"  height="100px"
                    width="150px">
            </div>
            @else
            <div class="col">
                <div class="form">
                    <label>Upload Image</label>
                    <input type="file" class="form-control" id="ogImage" placeholder="" accept='image/*' onchange="readURL(this,'#ogImagePreview')" name="ogImage">
                </div>
            </div>
            @endif
        </div>



        {{-- og url --}}
        <div class="row mb-3">
            <div class="col-sm-12 col-lg-3 col-md-12">
                Og Url
            </div>
            <div class="col">
                <div class="form-label-group">
                    <input type="text" class="form-control" id="ogUrl" placeholder="" name="ogUrl"
                        value="{{ $data1->ogUrl ?? ''}}">
                    <label for="">Url</label>
                </div>
            </div>
        </div>

        {{-- description --}}
        <div class="row mb-3">
            <div class="col-sm-12 col-lg-3 col-md-12">
                Description
            </div>
            <div class="col">
                <div class="form-label-group">
                    <input type="text" class="form-control" id="metadescription" placeholder="" name="metadescription"
                        value="{{ $data1->description ?? ''}}">
                    <label for="">description</label>
                </div>
            </div>
        </div>

        {{-- keyword --}}
        <div class="row mb-3">
            <div class="col-sm-12 col-lg-3 col-md-12">
                Keyword
            </div>
            <div class="col">
                <div class="form-label-group">
                    <input type="text" class="form-control" id="keywords" placeholder="" name="keywords"
                        value="{{ $data1->keywords ?? ''}}">
                    <label for="">keywords</label>
                </div>
            </div>
        </div>

        {{-- author --}}
        <div class="row mb-3">
            <div class="col-sm-12 col-lg-3 col-md-12">
                Author
            </div>
            <div class="col">
                <div class="form-label-group">
                    <input type="text" class="form-control" id="author" placeholder="" name="author"
                        value="{{ $data1->author ?? ''}}">
                    <label for="">author</label>
                </div>
            </div>
        </div>

        {{-- tages --}}
        <div class="row mb-3">
            <div class="col-sm-12 col-lg-3 col-md-12">
                Tages
            </div>
            <div class="col">
                <div class="form-label-group">
                    <input type="text" class="form-control" id="tages" placeholder="Hindi Title"
                        name="tages" value="{{ $data1->tages ?? ''}}">
                    <label for="">tages</label>
                </div>
            </div>
        </div>
        <div class="text-center form-action">
            <button type="submit" class="btn btn-primary text-uppercase">Submit</button>
        </div>

	</form>


</div>



<script>
	function readURL(input, tgt) {
		if (input.files && input.files[0]) {
			var reader = new FileReader();
			reader.onload = function(e) {
				document.querySelector(tgt).setAttribute("src", e.target.result);
			};
			reader.readAsDataURL(input.files[0]);
		}
	}
</script>

@endsection


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
