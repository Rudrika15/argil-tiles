@extends('layouts.app')
@section('seosection')
    <meta name="description"
        content="Discover Argil's state-of-the-art tile
manufacturing plants. Explore our advanced production technology and
sustainable practices." />
    <meta name="keywords"
        content="Argil Plants, Tile Manufacturing, Ceramic
Production, Industrial Plants, Argil Tiles Factory" />
    <meta property="og:title" content="Argil Group Manufacturing Plants –
Precision & Innovation">
    <meta property="og:description"
        content="Explore Argil Group’s state-of-the
-art manufacturing plants, where advanced technology meets precision
craftsmanship in artificial quartz stone production.">

    <meta property="og:url" content="https://argiltiles.com/plants">
    <meta name="twitter:title" content="Argil Group Manufacturing Plants –
Precision & Innovation">
    <meta name="twitter:description"
        content="Discover the cutting-edge
manufacturing facilities of Argil Group, where technology, quality, and
innovation drive the production of world-class artificial quartz stones.">

    <link rel="canonical" href="https://argiltiles.com/plants" data-react- helmet="true">
    <title>Argil Manufacturing Plants | Advanced Tile Production</title>
@endsection
@section('content')
    <!-- breadcrumb -->
    <div class="breadcrumb d-flex justify-content-between align-items-center">
        <div class="container">

            <div class="p-2">
                <h1 class="display-6 fw-bold">Home / Plants</h1>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h2 class="pt-4 ">Digital Wall Tiles</h2>
                <p class="text-justify">
                    The best quality Digital tiles are manufactured and delivered to the customers by ARGIL. We take
                    pride
                    in being the leaders in setting industry trends in wall tiles since last 25 years. We have the
                    largest
                    range of wall tiles in terms of sizes available as well as surface finish. The idea of the top
                    management is to give as many options as possible to make sure our existing customers and newer ones
                    relating to the brand will always get their choice met from our range. The sizes include 250 x 330
                    mm,
                    300 x 300 mm, 300 x 450 mm, 200 x 600 mm, 300 x 600 mm. The larger sizes like 200 x 600 & 300 x 600
                    mm
                    are an awesome range and give a feel of grandiose to any wall clad with them. The size gives an
                    impression of pride and power. The smaller sizes are ideal and affordable solution to the large
                    middle
                    class in India and across the world.
                </p>
                <p class="text-justify">
                    The Finishes available in the above sizes include High gloss, which replicates mirror finish. Satin,
                    the touch of silk. Rustic, the natural stones revisited. Wooden, bringing thick forests to your
                    home. The above parameters are met by plethora of designs which can be seen in the product catalogs
                    of the company. With Digital printing Technology on our Hands, the company has virtually no limit in
                    the looks and appearances of the tiles. The technology has given designer the flexibility to let
                    their imagination run wild and recreate any look. We have also permitted our bulk buyers as well as
                    design Specialist dealing with us to demand whatever theme or look they desire and we promise to
                    recreate it for them. All these add up to make the biggest range of wall tiles offering in India.
                    The sum total of different SKUs is more than 1000 making this unarguably one of the most wide range
                    in wall tiles manufacturers in the region.
                </p>
            </div>
            <div class="col-md-6 text-center">
                <img src="{{ asset('assets/asset/plantsimage.png') }}" alt="argil plants" title="argil plants"
                    loading="lazy" class="img-fluid w-75">
            </div>

        </div>
        <div class="row">
            <div class="col-md-12">
                <p class="text-justify">
                    ARGIL is already in collaboration with most of the top ceramic machinery suppliers like Sacmi,
                    System, B&T, Kera Jet, Modena, HRMEZE and many others. Rotocolor drum printing machine is the right
                    machine for with random effect printing at high resolution to give natural look to tiles. The Press
                    is one of the most important machine in tile production. Its effective use will lead to longer life
                    of tiles. We have a number of imported presses including Sacmi 1600, Lethai 1300, Sacmi 980 and
                    Sacmi 680. Both these manufacturers are leaders in Ceramic Machinery globally.
                </p>
                <h2 class="">DuraQuartz</h2>
                <p class="text-justify">

                    Argil DuraQuartz Surfaces' range of products is manufactured under a fully-automated production
                    process, including professional carving, air-drying, polishing, and scraping and thickening
                    techniques. At every stage of production, we remain alert to maintain the high-caliber precision and
                    top-in-class accuracy. No wonder, Argil DuraQuartz Surfaces' is rapidly becoming a synonym for style
                    statement with utmost quality across its growing fan base all over India and the world.The plant is
                    equipped with 18 head Polishing lines which provide high gloss on the surface and maintains smooth
                    finish along with flatness. The High Pressure, Vacuum and Vibrating press are inevitable component
                    of production. They instill the toughness and durability components of the Quartz Stone. The
                    Automatic Bridge cutting Machine empowers fast, accurate and efficient cutting and sizing of the
                    stones.

                </p>
                <h2 class="">Research and Development

                </h2>
                <p class="text-justify">
                    Since its inception, company has been keen on innovation and Research. From material to production
                    process to quality testing to enhancement of product performance, the company has and will invest in
                    research. We have a well established research centre in both our units. It is well equipped with a
                    laboratory and manned by experienced and expert people. The work on testing and improvement is done
                    round the clock. With every testing there is SPC and SQC involved to keep the Production System up
                    to date. Along with the regular activity, we have our researchers working on newer and better
                    product performance designs of the product. They vary parameters of material, production and ageing
                    to test and re-test new ideas. This gives birth to better and improved products over a period of
                    time.The innovation index too is controlled by innovating in every department of the company. This
                    activity is basically carried out by every individual in his or her area of work. The functional
                    heads and the supervisors are continuously looking to increase efficiency, reduce losses and
                    increase quality production.
                </p>
                <h2 class="">Design Department

                </h2>
                <p class="text-justify">
                    Product design is the single most important and market generating parameter. Thus we have
                    established a computerized Design department with fine arts experts. Both the units have their
                    independent teams who work help each other when needed but take up their own challenges on designing
                    of fresh looks and trendy designs. We have also collaborated with Spanish and Italian companies for
                    the design know how.The sole role of design department in both the units is to roll out trendy as
                    well as new coming designs that will work in the market. They have a consistent communication with
                    the marketing team who give them new thoughts and demands prevailing in the markets. Based on these,
                    the design teams churn out new designs.Few of all the designs proposed are accepted, as we believe
                    in delivering the best, not everything. The designs are then market tested before commercialization.
                    We make sure that needs of the market are beaten and we are always leader and never copycats. Being
                    pioneers in introduction fresh styles and range of products makes us feel proud.
                </p>
            </div>
        </div>
    </div>
@endsection
