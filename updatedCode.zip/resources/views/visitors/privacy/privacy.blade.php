@extends('layouts.app')
@section('seosection')
    <meta name="description"
        content="Read the privacy policy of Argil Tiles to understand how we collect, use, and protect your data.">
    <meta name="keywords" content="Privacy Policy, Argil Tiles, User Data, Cookies, Security">
    <meta property="og:title" content="Privacy Policy | Argil Tiles">
    <meta property="og:description" content="Learn how Argil Tiles collects, uses, and protects your personal information.">
    <meta property="og:url" content="https://argiltiles.com/privacyPolicy">
    <!-- Twitter Card Meta Tags for Privacy Policy -->
    <meta name="twitter:title" content="Privacy Policy | Argil Tiles – Your Data, Our Responsibility">
    <meta name="twitter:description"
        content="Learn how Argil Tiles collects, uses, and protects your personal data with transparency and care.">
    <meta name="twitter:url" content="https://argiltiles.com/privacyPolicy">
    <link rel="canonical" href="https://argiltiles.com/privacyPolicy">


    <title>Privacy Policy | Argil Tiles – Your Data, Our Responsibility</title>
@endsection
@section('content')
     <!-- breadcrumb -->
     <div class="breadcrumb d-flex justify-content-between align-items-center">
        <div class="container">

            <div class="p-2">
                <h1 class="display-6 fw-bold">Home / PrivacyPolicy</h1>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="mt-3 fw-bold" >Philosophy</h2 class="mt-3" >
                <p class="text-justify">Mahadev built the Argil Ceramics app as a Free app. This SERVICE is
                    provided by Mahadev at no cost and is intended for use as is. This page is used to inform visitors
                    regarding my policies with the collection, use, and disclosure of Personal Information if anyone decided
                    to use my Service. If you choose to use my Service, then you agree to the collection and use of
                    information in relation to this policy. The Personal Information that I collect is used for providing
                    and improving the Service. I will not use or share your information with anyone except as described in
                    this Privacy Policy. The terms used in this Privacy Policy have the same meanings as in our Terms and
                    Conditions, which is accessible at Argil Ceramics unless otherwise defined in this Privacy Policy.</p>
            </div>
            <div class="col-md-12">
                <h2 class="mt-3 fw-bold">Information Collection and Use</h2 class="mt-3" >
                <p class="text-justify">For a better experience, while using our Service, I may require you to
                    provide us with certain personally identifiable information, including but not limited to Wall Tiles,
                    Quartz, Quartz Surface, Ceramics. The information that I request will be retained on your device and is
                    not collected by me in any way. The app does use third party services that may collect information used
                    to identify you. Link to privacy policy of third party service providers used by the app</p>
            </div>
            <div class="col-md-12">
                <h2 class="mt-3 fw-bold">Log Data</h2 class="mt-3" >
                <p class="text-justify">I want to inform you that whenever you use my Service,
                    in a case of an
                    error in the app I collect data and information (through third party products) on your phone called Log
                    Data. This Log Data may include information such as your device Internet Protocol (“IP”) address, device
                    name, operating system version, the configuration of the app when utilizing my Service, the time and
                    date of your use of the Service, and other statistics.</p>
            </div>
            <div class="col-md-12">
                <h2 class="mt-3 fw-bold">Cookies</h2 class="mt-3" >
                <p class="text-justify">Cookies are files with a small amount of data that are
                    commonly used as
                    anonymous unique identifiers. These are sent to your browser from the websites that you visit and are
                    stored on your device's internal memory. This Service does not use these “cookies” explicitly. However,
                    the app may use third party code and libraries that use “cookies” to collect information and improve
                    their services. You have the option to either accept or refuse these cookies and know when a cookie is
                    being sent to your device. If you choose to refuse our cookies, you may not be able to use some portions
                    of this Service.</p>
            </div>
            <div class="col-md-12">
                <h2 class="mt-3 fw-bold">Service Providers</h2 class="mt-3" >
                <p class="text-justify">I may employ third-party companies and individuals due
                    to the following
                    reasons: To facilitate our Service;To provide the Service on our behalf;To perform Service-related
                    services; orTo assist us in analyzing how our Service is used. I want to inform users of this Service
                    that these third parties have access to your Personal Information. The reason is to perform the tasks
                    assigned to them on our behalf. However, they are obligated not to disclose or use the information for
                    any other purpose.
                </p>
            </div>
            <div class="col-md-12">
                <h2 class="mt-3 fw-bold">Security</h2 class="mt-3" >
                <p class="text-justify">I value your trust in providing us your Personal
                    Information, thus we are
                    striving to use commercially acceptable means of protecting it. But remember that no method of
                    transmission over the internet, or method of electronic storage is 100% secure and reliable, and I
                    cannot guarantee its absolute security.

                </p>
            </div>
            <div class="col-md-12">
                <h2 class="mt-3 fw-bold">Links to Other Sites</h2 class="mt-3" >
                <p class="text-justify">This Service may contain links to other sites. If you
                    click on a
                    third-party link, you will be directed to that site. Note that these external sites are not operated by
                    me. Therefore, I h4 class="mt-3" ly advise you to review the Privacy Policy of these websites. I have no control over
                    and assume no responsibility for the content, privacy policies, or practices of any third-party sites or
                    services.
                </p>
            </div>
            <div class="col-md-12">
                <h2 class="mt-3 fw-bold">Children’s Privacy
                </h2 class="mt-3" >
                <p class="text-justify">These Services do not address anyone under the age of
                    13. I do not
                    knowingly collect personally identifiable information from children under 13. In the case I discover
                    that a child under 13 has provided me with personal information, I immediately delete this from our
                    servers. If you are a parent or guardian and you are aware that your child has provided us with personal
                    information, please contact me so that I will be able to do necessary actions.
                </p>
            </div>
            <div class="col-md-12">
                <h2 class="mt-3 fw-bold">Changes to This Privacy Policy
                </h2 class="mt-3" >
                <p class="text-justify">I may update our Privacy Policy from time to time.
                    Thus, you are advised
                    to review this page periodically for any changes. I will notify you of any changes by posting the new
                    Privacy Policy on this page. This policy is effective as of 2020-06-15

                </p>
            </div>
            <div class="col-md-12">
                <h2 class="mt-3 fw-bold">Contact Us
                </h2 class="mt-3" >
                <p class="text-justify">If you have any questions or suggestions about my
                    Privacy Policy, do not
                    hesitate to contact me at +91 98252 11465.
                </p>
            </div>
        </div>
    </div>
    </div>
@endsection
