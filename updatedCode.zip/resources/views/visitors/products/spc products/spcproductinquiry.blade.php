@extends('layouts.app')
@section('seosection')
    <meta name="description"
        content="Argil is a leading manufacturer of premium artificial quartz stone slabs in Morbi, Gujarat. Explore quartz for homes & businesses.">
    <meta name="keywords" content="Artificial Quartz, Quartz Slabs, Quartz Manufacturers, Morbi Quartz, India Quartz Stone">
    <meta property="og:title" content="SPC Product Inquiry | Argil Quartz Surfaces" data-react-helmet="true">
    <meta property="og:description"
        content="Explore premium artificial quartz stone slabs by Argil, a leading manufacturer in Morbi, Gujarat. Perfect for homes and businesses."
        data-react-helmet="true">
    <meta property="og:url" content="https://argiltiles.com/spcproductinquiry/{{ $data->id }}" data-react-helmet="true">

    <meta name="twitter:title" content="SPC Product Inquiry | Argil Quartz Surfaces" data-react-helmet="true">
    <meta name="twitter:description"
        content="Explore premium artificial quartz stone slabs by Argil, a leading manufacturer in Morbi, Gujarat. Perfect for homes and businesses."
        data-react-helmet="true">

        <link rel="canonical" href="{{ url()->current() }}">

    <title> {{$data->names}} | Premium SPC Flooring Solutions by Argil</title>


    <script type="application/ld+json">
        {
          "@context": "https://schema.org/",
          "@type": "Product",
          "name": "{{ $data->names }}",
          "image": ["{{ asset('spc/' . $data->mainImg) }}"],
          "description": " Thickness : {{ $data->thicknesses }} , Primary color : {{ $data->primarycolors }} ",
          "brand": {
            "@type": "Brand",
            "name": "Argil Group"
          },
          "review": [

          {
            "@type": "Review",
            "author": {
              "@type": "Person",
              "name": "Chandan Gupta"
            },
            "datePublished": "{{ $data->created_at->toDateString() }}",
            "reviewBody": "
            Thrilled with the SPC flooring from Argil. It has a clean, stylish appearance and feels incredibly sturdy underfoot. It’s transformed our room with a modern touch and is super low-maintenance. Definitely recommend!"
          }
          ]

        }
        </script>


@endsection
@section('content')

     <!-- breadcrumb -->
     <div class="breadcrumb d-flex justify-content-between align-items-center">
        <div class="container">

            <div class="p-2">
                <h1 class="display-6 fw-bold">Home / {{ $data->names }}</h1>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->
    <div class="container">

        <div class="row pb-5">
            <h2 class="text-center fw-bold pt-5">SPC Flooring tiles</h2>
            <div class="col-md-4 pt-5">
                <div class="card">
                    <img src="{{ asset('spc/' . $data->mainImg) }}" class="img-thumbnail" style="height: 400px;" alt="spc product" title="spc product" loading="lazy">
                </div>
            </div>
            <div class="col-md-8 pt-5">
                <div class="row">
                    <div class="col-md-6">

                        <h3>Serise Name ( s ) :</h3>
                        <p>{{ $data->names }}</p>
                        <h3>With Enhanced Beveled Edges :</h3>
                        <p>{{ $data->edges }}</p>
                        <h3>Thickness :</h3>
                        <p>{{ $data->thicknesses }}</p>
                        <h3>Click Type :</h3>
                        <p>{{ $data->clicktype }}</p>
                        <h3>Shade Variation :</h3>
                        <p>{{ $data->shadeVariation }}</p>
                    </div>
                    <div class="col-md-6">

                        <h3>Primary Color (s) :</h3>
                        <p>{{ $data->primarycolors }}</p>
                        <h3>Backing Type :</h3>
                        <p>{{ $data->backingType }}</p>
                        <h3>Style :</h3>
                        <p>{{ $data->style }}</p>
                        <h3>Wear Layer :</h3>
                        <p>{{ $data->wearLayer }}</p>
                    </div>
                </div>

                <form class="mt-3" id="contact-form" method="POST">
                        @csrf
                        {{-- <input type="hidden" name="product_id" value="{{ $data->id }}"> --}}
                        <input type="hidden" name="product_name" value="{{ $data->names }}">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="floatingName" placeholder="Your Name" name="form_name" required oninvalid="this.setCustomValidity('The name field is required.')" oninput="this.setCustomValidity('')">
                            <label for="floatingName">Your Name</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input type="email" class="form-control" id="floatingEmail" placeholder="name@example.com" name="form_email" required oninvalid="this.setCustomValidity('The email field is required.')" oninput="this.setCustomValidity('')">
                            <label for="floatingEmail">Email</label>
                        </div>

                        <div class="form-floating mb-3">
                            <input type="tel" class="form-control" id="floatingContact" placeholder="Contact Number" name="form_phone" required oninvalid="this.setCustomValidity('The contact field is required.')" oninput="this.setCustomValidity('')">
                            <label for="floatingContact">Contact Number</label>
                        </div>

                        <div class="form-floating mb-3">
                            <textarea class="form-control" id="floatingMessage" name="form_message" placeholder="Your Message" style="height: 150px;" required oninvalid="this.setCustomValidity('The message field is required.
')" oninput="this.setCustomValidity('')"></textarea>
                            <label for="floatingMessage">Your Message</label>
                        </div>
                        <input type="hidden" name="product_details" value="spc product">
                        <button type="submit" class="btn btn-primary w-100 mt-3">Submit</button>
                    </form>

            </div>

        </div>

    </div>

    </div>



    {{-- inquiry  --}}
    <script>
        document.getElementById('contact-form').addEventListener('submit', function(event) {
            event.preventDefault();

            const form = this;
            const submitBtn = form.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;

            // Check if all required fields are filled
            const isFormValid = form.checkValidity();

            // If the form is valid, change the button text to "Submitting..."
            if (isFormValid) {
                submitBtn.innerHTML = "Submitting...";
            } else {
                // If form is not valid, just return without making AJAX request
                return;
            }

            // Disable the button to prevent multiple submissions
            submitBtn.disabled = true;

            const formData = new FormData(form);

            fetch("{{ Route('send.inquiry') }}", {
                    method: 'POST',
                    body: formData,
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}'
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        Swal.fire({
                            title: 'Thank you!',
                            text: 'Your inquiry has been submitted successfully.',
                            icon: 'success',
                            confirmButtonText: 'OK',
                            customClass: {
                                title: 'swal-title',
                                htmlContainer: 'swal-text',
                                confirmButton: 'swal-button'
                            }
                        });

                        // Reset the form
                        form.reset();
                    }
                })
                .finally(() => {
                    // Re-enable the button and restore original text
                    submitBtn.disabled = false;
                    submitBtn.innerHTML = originalText;
                });
        });
     </script>
@endsection
